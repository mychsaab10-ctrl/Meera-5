package com.meera.ai.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import com.meera.ai.R
import com.meera.ai.voice.CallState
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun GlowCard(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    val border = BorderStroke(1.dp, Brush.linearGradient(listOf(Cyan.copy(alpha = 0.55f), Purple.copy(alpha = 0.55f))))
    val m = if (onClick != null) modifier.clip(RoundedCornerShape(18.dp)).clickable { onClick() } else modifier
    Card(
        modifier = m,
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        border = border
    ) { Column(Modifier.padding(14.dp), content = content) }
}

@Composable
fun SectionTitle(text: String) {
    Text(text, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.padding(top = 14.dp, bottom = 6.dp))
}

@Composable
fun Chip(text: String, ok: Boolean? = null) {
    val c = when (ok) { true -> Color(0xFF34D399); false -> Pink; null -> MaterialTheme.colorScheme.onSurfaceVariant }
    Row(
        Modifier.clip(RoundedCornerShape(50)).background(c.copy(alpha = 0.15f)).padding(horizontal = 10.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) { Text(text, color = c, fontSize = 12.sp) }
}

@Composable
fun VoiceOrb(state: CallState, modifier: Modifier = Modifier) {
    val inf = rememberInfiniteTransition(label = "orb")
    val rot by inf.animateFloat(0f, 360f, infiniteRepeatable(tween(7000, easing = LinearEasing)), label = "rot")
    val speed = if (state == CallState.Speaking) 450 else 1400
    val pulse by inf.animateFloat(
        0.92f, 1.08f, infiniteRepeatable(tween(speed, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse"
    )
    val base = when (state) {
        CallState.Listening -> Cyan
        CallState.Thinking -> Purple
        CallState.Speaking -> Pink
        CallState.Connecting -> Purple
        CallState.Error -> Color(0xFFFF4D6D)
        CallState.Idle -> Color(0xFF6B5E8F)
    }
    Canvas(modifier) {
        val c = center
        val k = if (state == CallState.Idle) 1f else pulse
        val r = size.minDimension / 2f * 0.72f * k
        drawCircle(
            brush = Brush.radialGradient(listOf(base.copy(alpha = 0.55f), Color.Transparent), center = c, radius = r * 1.5f),
            radius = r * 1.5f, center = c
        )
        rotate(rot, c) {
            drawCircle(
                brush = Brush.sweepGradient(listOf(Cyan, Purple, Pink, Cyan), center = c),
                radius = r, center = c, style = Stroke(width = 7.dp.toPx())
            )
        }
        drawCircle(color = base.copy(alpha = 0.22f), radius = r * 0.78f, center = c)
        drawCircle(color = base, radius = r * 0.14f, center = c)
    }
}

/**
 * Meera's avatar (8 light WebP images, ~50 KB each, no extra library).
 * mood: normal | happy | excited | sad | loving | thinking.  talking = mouth open/close while she speaks.
 * It blinks every few seconds and floats gently.
 */
@Composable
fun Avatar(size: Dp, mood: String = "normal", talking: Boolean = false, modifier: Modifier = Modifier) {
    var blink by remember { mutableStateOf(false) }
    var mouth by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(3200L + (0..1800).random())
            blink = true
            delay(150)
            blink = false
        }
    }
    LaunchedEffect(talking) {
        if (talking) {
            while (true) { mouth = !mouth; delay(230) }
        } else mouth = false
    }
    val inf = rememberInfiniteTransition(label = "avatar")
    val bob by inf.animateFloat(
        -3f, 3f, infiniteRepeatable(tween(2600, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "bob"
    )
    val res = when {
        talking && mouth -> R.drawable.avatar_talking
        blink && !talking && mood in listOf("normal", "thinking", "excited") -> R.drawable.avatar_blink
        mood == "happy" -> R.drawable.avatar_happy
        mood == "excited" -> R.drawable.avatar_excited
        mood == "sad" -> R.drawable.avatar_sad
        mood == "loving" -> R.drawable.avatar_loving
        mood == "thinking" -> R.drawable.avatar_thinking
        else -> R.drawable.avatar_normal
    }
    Box(
        modifier.size(size).graphicsLayer { translationY = bob.dp.toPx() }
            .clip(CircleShape)
            .border(3.dp, Brush.sweepGradient(listOf(Cyan, Purple, Pink, Cyan)), CircleShape)
    ) {
        Crossfade(targetState = res, animationSpec = tween(110), label = "avatarImg") { r ->
            Image(painterResource(r), contentDescription = "Meera", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }
    }
}

/** Rotating HUD ring (ticks + glowing arcs) drawn around the avatar - the "tech lab" look. */
@Composable
fun HudRing(modifier: Modifier = Modifier) {
    val inf = rememberInfiniteTransition(label = "hud")
    val a by inf.animateFloat(0f, 360f, infiniteRepeatable(tween(24000, easing = LinearEasing)), label = "a")
    val b by inf.animateFloat(360f, 0f, infiniteRepeatable(tween(36000, easing = LinearEasing)), label = "b")
    Canvas(modifier) {
        val c = center
        val r = size.minDimension / 2f
        drawCircle(Brush.radialGradient(listOf(Cyan.copy(alpha = 0.28f), Color.Transparent), center = c, radius = r), r, c)
        rotate(a, c) {
            for (i in 0 until 90) {
                val ang = i * 4f * (PI.toFloat() / 180f)
                val long = i % 5 == 0
                val r1 = r * 0.93f
                val r2 = r1 + (if (long) 9.dp.toPx() else 5.dp.toPx())
                drawLine(
                    Cyan.copy(alpha = if (long) 0.85f else 0.4f),
                    Offset(c.x + r1 * cos(ang), c.y + r1 * sin(ang)), Offset(c.x + r2 * cos(ang), c.y + r2 * sin(ang)),
                    strokeWidth = if (long) 2.dp.toPx() else 1.dp.toPx()
                )
            }
        }
        rotate(b, c) {
            val s = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
            val rr = r * 0.86f
            drawArc(Pink, 200f, 60f, false, Offset(c.x - rr, c.y - rr), Size(rr * 2, rr * 2), style = s)
            drawArc(Cyan, 20f, 60f, false, Offset(c.x - rr, c.y - rr), Size(rr * 2, rr * 2), style = s)
            drawArc(Purple, 300f, 30f, false, Offset(c.x - rr, c.y - rr), Size(rr * 2, rr * 2), style = s)
        }
        drawCircle(Purple.copy(alpha = 0.55f), r * 0.8f, c, style = Stroke(1.5.dp.toPx()))
    }
}

/** Dark grid + perspective floor behind the Home screen. */
fun Modifier.techLabBackground(): Modifier = this.drawBehind {
    drawRect(Brush.verticalGradient(listOf(Color(0xFF05030F), Color(0xFF0B0720), Color(0xFF140B33))))
    val w = size.width
    val h = size.height
    val horizon = h * 0.72f
    val grid = Cyan.copy(alpha = 0.06f)
    var x = 0f
    while (x < w) { drawLine(grid, Offset(x, 0f), Offset(x, horizon), 1f); x += 48.dp.toPx() }
    var y = 0f
    while (y < horizon) { drawLine(grid, Offset(0f, y), Offset(w, y), 1f); y += 48.dp.toPx() }
    val floor = Purple.copy(alpha = 0.28f)
    for (i in -12..12) {
        drawLine(floor, Offset(w / 2f, horizon), Offset(w / 2f + i * w * 0.16f, h), 1.5f)
    }
    for (i in 1..9) {
        val yy = horizon + (h - horizon) * (i / 9f) * (i / 9f)
        drawLine(floor, Offset(0f, yy), Offset(w, yy), 1.5f)
    }
    drawLine(Cyan.copy(alpha = 0.5f), Offset(0f, horizon), Offset(w, horizon), 2f)
}
