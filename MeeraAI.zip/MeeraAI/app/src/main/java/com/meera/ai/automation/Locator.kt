package com.meera.ai.automation

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.CancellationSignal
import android.os.Looper
import android.os.SystemClock
import androidx.core.content.ContextCompat
import com.meera.ai.Meera
import com.meera.ai.ToolOut
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.util.Locale
import kotlin.coroutines.resume

/**
 * Gets the phone's real GPS/network location on request ("where am I?", "what is near me?", "guide me to ...").
 * The location is read only when the user asks, is never stored, and is only sent to Gemini as the tool result
 * of that question. Accuracy is whatever Android reports (we say it honestly): outdoors usually 5-30 m,
 * indoors it can be much worse.
 */
object Locator {
    class Fix(val lat: Double, val lon: Double, val accuracyM: Float, val ageSec: Long, val provider: String, val address: String?)

    /** Last fix of this app run (used by "find nearby" / "show me on the map"). Not saved to disk. */
    @Volatile var last: Fix? = null

    fun hasPermission(ctx: Context): Boolean =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun hasFine(ctx: Context): Boolean =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    /** Tool "get_location". */
    suspend fun tool(): ToolOut {
        val ctx = Meera.app
        if (!hasPermission(ctx)) {
            val ask = Meera.requestLocation
            return if (ask != null) {
                ask()
                ToolOut("Location permission is needed. The permission dialog was shown to the user. Tell them to tap Allow and then ask again.")
            } else ToolOut("Location permission is missing. Ask the user to allow Location in Meera's Permissions screen.")
        }
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val gpsOn = try { lm.isProviderEnabled(LocationManager.GPS_PROVIDER) } catch (e: Exception) { false }
        val netOn = try { lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) } catch (e: Exception) { false }
        if (!gpsOn && !netOn) {
            return ToolOut("Location services are switched OFF on the phone. Ask the user to turn on Location (you can call phone_action open_settings with query location).")
        }
        val fix = current(ctx, lm, gpsOn, netOn)
            ?: return ToolOut("Could not get a location fix in time. Ask the user to go near a window or outside and try again.")
        last = fix
        val acc = Math.round(fix.accuracyM)
        val quality = when {
            fix.accuracyM <= 30f -> "good"
            fix.accuracyM <= 100f -> "fair"
            else -> "poor (the real position may be several hundred metres away)"
        }
        return ToolOut(
            "LOCATION: latitude ${"%.6f".format(Locale.US, fix.lat)}, longitude ${"%.6f".format(Locale.US, fix.lon)}, " +
                "accuracy about $acc m ($quality), source ${fix.provider}, fix age ${fix.ageSec}s. " +
                "Address: ${fix.address ?: "not available (no geocoder on this phone)"}. " +
                "Map link: https://maps.google.com/?q=${fix.lat},${fix.lon}. " +
                "Tell the user the address and the accuracy honestly. Use this position to guide them; to start turn-by-turn directions call phone_action navigate."
        )
    }

    @SuppressLint("MissingPermission")
    private suspend fun current(ctx: Context, lm: LocationManager, gpsOn: Boolean, netOn: Boolean): Fix? {
        val providers = ArrayList<String>()
        if (gpsOn && hasFine(ctx)) providers.add(LocationManager.GPS_PROVIDER)
        if (netOn) providers.add(LocationManager.NETWORK_PROVIDER)
        var loc: Location? = null
        for (p in providers) {
            loc = fresh(ctx, lm, p)
            if (loc != null) break
        }
        if (loc == null) {
            // fall back to the freshest last known position (max 10 minutes old)
            for (p in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)) {
                val l = try { lm.getLastKnownLocation(p) } catch (e: Exception) { null }
                if (l != null && (loc == null || l.time > loc.time)) loc = l
            }
            if (loc != null && System.currentTimeMillis() - loc.time > 10 * 60_000L) loc = null
        }
        val l = loc ?: return null
        val ageSec = ((SystemClock.elapsedRealtimeNanos() - l.elapsedRealtimeNanos) / 1_000_000_000L).coerceAtLeast(0L)
        val addr = withContext(Dispatchers.IO) { address(ctx, l.latitude, l.longitude) }
        return Fix(l.latitude, l.longitude, if (l.hasAccuracy()) l.accuracy else 9999f, ageSec, l.provider ?: "?", addr)
    }

    @SuppressLint("MissingPermission")
    private suspend fun fresh(ctx: Context, lm: LocationManager, provider: String): Location? =
        withTimeoutOrNull(12_000L) {
            suspendCancellableCoroutine<Location?> { cont ->
                if (Build.VERSION.SDK_INT >= 30) {
                    val cs = CancellationSignal()
                    cont.invokeOnCancellation { cs.cancel() }
                    lm.getCurrentLocation(provider, cs, ContextCompat.getMainExecutor(ctx)) { l ->
                        if (cont.isActive) cont.resume(l)
                    }
                } else {
                    val listener = object : LocationListener {
                        override fun onLocationChanged(l: Location) {
                            lm.removeUpdates(this)
                            if (cont.isActive) cont.resume(l)
                        }
                        @Deprecated("Deprecated in Java")
                        override fun onStatusChanged(p: String?, status: Int, extras: Bundle?) {}
                        override fun onProviderEnabled(p: String) {}
                        override fun onProviderDisabled(p: String) {}
                    }
                    lm.requestLocationUpdates(provider, 0L, 0f, listener, Looper.getMainLooper())
                    cont.invokeOnCancellation { lm.removeUpdates(listener) }
                }
            }
        }

    @Suppress("DEPRECATION")
    private fun address(ctx: Context, lat: Double, lon: Double): String? = try {
        if (!Geocoder.isPresent()) null
        else Geocoder(ctx, Locale.ENGLISH).getFromLocation(lat, lon, 1)?.firstOrNull()?.let { a ->
            (0..a.maxAddressLineIndex).map { a.getAddressLine(it) }.filter { !it.isNullOrBlank() }.joinToString(", ").ifBlank { null }
        }
    } catch (e: Exception) {
        null
    }
}
