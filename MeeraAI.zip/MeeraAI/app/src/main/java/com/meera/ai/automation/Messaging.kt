package com.meera.ai.automation

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import androidx.core.content.ContextCompat
import com.meera.ai.Meera
import com.meera.ai.ToolOut
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONObject

/**
 * WhatsApp / SMS messages by phone number or by contact name.
 *
 * Privacy: contacts are searched ONLY on the phone. The model never receives a contact's name or
 * number - it only sees what the user said and the question to ask. Contacts permission is requested
 * the first time a name (not a number) is used.
 *
 * Flow: request() -> Meera asks "send it?" -> user says yes (or haan) -> deliver() opens the chat with the
 * message typed in -> (optional) the accessibility service taps Send. Android reports whether the tap
 * was performed; Meera never claims the message was delivered.
 */
object Messaging {

    private sealed class Target {
        class Ok(val number: String, val label: String) : Target()
        class Fail(val say: String) : Target()
    }

    fun request(args: JSONObject): ToolOut {
        val appRaw = args.optString("app").lowercase()
        val kind = if (appRaw.contains("sms") || appRaw == "text" || appRaw == "message" || appRaw == "messages") "sms" else "whatsapp"
        val to = args.optString("to").trim()
        val msg = args.optString("message").trim()
        if (to.isEmpty() || msg.isEmpty()) return ToolOut("Who should receive the message and what should it say? Please tell me both.")

        val target = resolve(to)
        if (target is Target.Fail) return ToolOut(target.say)
        val ok = target as Target.Ok

        val appName = if (kind == "sms") "SMS" else "WhatsApp"
        Meera.toast("$appName: ${ok.label}") // shown on screen only; never sent to Gemini
        return Meera.confirmThen("Send this message to $to on $appName: \"$msg\"? (yes / no)") {
            deliver(kind, ok.number, msg)
        }
    }

    // ───────────── recipient ─────────────

    private fun resolve(to: String): Target {
        val digits = to.filter { it.isDigit() }
        val looksLikeNumber = digits.length >= 7 && to.none { it.isLetter() }
        if (looksLikeNumber) {
            val n = intl(to) ?: return Target.Fail(
                "I could not work out the country code. Give the full number like +92..., or set a default country code in Settings."
            )
            return Target.Ok(n, "+$n")
        }

        val granted = ContextCompat.checkSelfPermission(Meera.app, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED
        if (!granted) {
            val req = Meera.requestContacts
            return if (req != null) {
                req()
                Target.Fail("Contacts permission is needed to send by name. The permission dialog was shown. Please allow it and ask again.")
            } else {
                Target.Fail("Contacts permission is needed to send by name. Open Meera and allow Contacts in the Permissions screen.")
            }
        }

        val hits = lookup(to)
        if (hits.isEmpty()) return Target.Fail("No contact with that name was found on this phone. Please give the number.")
        val byNumber = LinkedHashMap<String, String>() // number -> display name
        for ((name, raw) in hits) {
            val n = intl(raw) ?: continue
            if (!byNumber.containsKey(n)) byNumber[n] = name
        }
        if (byNumber.isEmpty()) return Target.Fail("That contact's number is not in a usable format. Please give the number.")
        if (byNumber.size == 1) {
            val e = byNumber.entries.first()
            return Target.Ok(e.key, "${e.value} (+${e.key})")
        }
        val exact = byNumber.entries.filter { it.value.equals(to, ignoreCase = true) }
        if (exact.size == 1) return Target.Ok(exact[0].key, "${exact[0].value} (+${exact[0].key})")
        return Target.Fail("There are several contacts with that name. Please give the full name or the number.")
    }

    private fun lookup(name: String): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        try {
            Meera.app.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ),
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?", arrayOf("%$name%"), null
            )?.use { c ->
                while (c.moveToNext() && out.size < 25) out.add((c.getString(0) ?: "") to (c.getString(1) ?: ""))
            }
        } catch (e: Exception) {
            // permission revoked or provider error: treated as "no contact found"
        }
        return out
    }

    /** International digits without '+', or null if the country is unknown. */
    private fun intl(raw: String): String? {
        val plus = raw.trim().startsWith("+")
        val d = raw.filter { it.isDigit() }
        if (d.length < 7) return null
        if (plus) return d
        if (d.startsWith("00")) return d.drop(2)
        val cc = Meera.settings.countryCode.filter { it.isDigit() }
        if (d.startsWith("0")) return if (cc.isNotEmpty()) cc + d.drop(1) else null
        if (cc.isNotEmpty() && d.length <= 10) return cc + d
        return d
    }

    // ───────────── sending ─────────────

    private fun installed(ctx: Context, pkg: String): Boolean = try {
        ctx.packageManager.getPackageInfo(pkg, 0); true
    } catch (e: Exception) { false }

    private fun deliver(kind: String, number: String, msg: String): String {
        val ctx = Meera.app
        val intent: Intent
        if (kind == "whatsapp") {
            val pkg = listOf("com.whatsapp", "com.whatsapp.w4b").firstOrNull { installed(ctx, it) }
                ?: return "WhatsApp is not installed on this phone."
            intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$number?text=" + Uri.encode(msg))).setPackage(pkg)
        } else {
            intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:+$number")).putExtra("sms_body", msg)
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            ctx.startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            return "No app on this phone can handle this."
        } catch (e: SecurityException) {
            return "Android denied the permission."
        }

        if (!Meera.accessGate.value || MeeraAccessibilityService.instance == null) {
            return "The chat is open with the message typed in. Screen control is off, so please press Send yourself."
        }
        Meera.scope.launch {
            delay(2200)
            var done = false
            repeat(10) {
                if (!done) {
                    done = MeeraAccessibilityService.instance?.tapSend(kind) == true
                    if (!done) delay(600)
                }
            }
            val r = if (done) "The Send tap was performed (Android confirmed). Please check the delivery yourself."
            else "The Send button was not found. Please press Send yourself."
            Meera.log.value = r
            Meera.toast(r)
        }
        return "The chat is open with the message typed in. I am trying to press Send; the result will show on screen."
    }
}
